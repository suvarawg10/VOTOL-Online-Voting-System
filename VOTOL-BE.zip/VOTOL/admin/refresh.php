<?php
require_once('../connection.php');
// retrieving candidate(s) results based on position
if (isset($_POST['Submit'])){   

  $position = addslashes( $_POST['position'] );
  
    $results = mysqli_query($conn,"SELECT * FROM tbcandidates where candidate_position='$position'");
	$count= mysqli_num_rows($result);
    
}		
   
        // do nothing
?> 
<?php
// retrieving positions sql query
$positions= mysqli_query($conn,"SELECT * FROM tbpositions")
or die("There are no records to display ... \n" . mysqli_error()); 
?>
<?php
session_start();
//If your session isn't valid, it returns you to the login screen for protection
if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
}
?>

<?php if(isset($_POST['Submit'])){
		$sum=0;
		//SELECT SUM(`candidate_cvotes`) FROM `tbcandidates
		$s= mysqli_query($conn,"SELECT SUM(candidate_cvotes) FROM tbcandidates where candidate_position='$position'")or die("There are no records to display ... \n" . mysqli_error()); 
		$row=mysqli_fetch_array($s);
		$sum=$row['SUM(candidate_cvotes)'];
	} ?>


<!DOCTYPE html>

<html>
<head>
<title>online voting</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
 <link rel="stylesheet" href="css/style.css">
<script language="JavaScript" src="js/admin.js">
</script>

</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
  
    <div class="fl_left">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-pinterest" href="https://uk.pinterest.com/"><i class="fa fa-pinterest"></i></a></li>
        <li><a class="faicon-twitter" href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="https://dribbble.com/"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-rss" href="https://www.rss.com/"><i class="fa fa-rss"></i></a></li>
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace inline pushright">
        <li><i class="fa fa-phone"></i> +8801773254014</li>
        <li><i class="fa fa-envelope-o"></i> suvarnawg10@gmail.com </li>
      </ul>
    </div>
   
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    
    <div id="logo" class="fl_left">
      <h1><a href="..\index.html">ONLINE VOTING</a></h1>
    </div>
    
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="refresh.php">Home</a></li>
        <li><a class="drop" href="#">Admin Panel Pages</a>
          <ul>
            <li><a href="manage-admins.php">Manage Admin</a></li>
            <li><a href="positions.php">Manage Positions</a></li>
            <li><a href="candidates.php">Manage Candidates</a></li>
            <li><a href="refresh.php">Results</a></li>
          </ul>
        </li>
        
        <li><a href="../index.php">Voter Panel</a></li>
        <li><a href="logout.php">Logout</a></li>

      </ul>
    </nav>
    
  </header>
</div>

<div >
 
  <div >
    <table width="420px" style="margin-bottom:0px;">
    <form  method="post" action="refresh.php" onSubmit="return positionValidate(this)">
    <tr>
        <td style="color:#000000";>Choose Position</td>
        <td><SELECT NAME="position" id="position">
        <OPTION  VALUE="select"><p style="color:black";>select</p>
        <?php 
        //loop through all table rows
        while ($row= mysqli_fetch_array($positions)){
          echo "<OPTION VALUE=$row[position_name]>$row[position_name]"; 
        }
        ?>
        </SELECT></td>
        <td style="color:black";><input type="submit" name="Submit" value="See Results" /></td>
    </tr>
  
    </form> 
    </table>
	</div>
</div>
	
<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/background1.jpg');">
  <section id="testimonials" class="hoc container clear" width="100%"> 
   
    <h2 class="font-x3 uppercase btmspace-80 underlined">VOT<a href="#">OL</a></h2>
    <ul class="nospace group" width="100%">
	<?php echo  "<div id='header' align='center'><h1>Poll Result Of Position ".$position."</h1></div>"; ?>
       <li class="one_third" style="width:100%;">
	   <blockquote width="100%">
<?php	
 if(isset($_POST['Submit']))
 {$flag=True;
	
	
	while($row = mysqli_fetch_array($results)){
		
      if ($flag){
      $candidate_name_1=$row['candidate_name']; // first candidate name
      $candidate_1=$row['candidate_cvotes']; // first candidate votes
	  $flag=False;
	  echo "<br>".$candidate_name_1.": votes = ".$candidate_1."<br><img src='images/candidate-1.gif' style='width:".(100*round($candidate_1/($sum),2))."%;height:20px;'>";
	  echo "<br>".(100*round($candidate_1/($sum),2))." % of ".$sum." total votes<br><br>";
      }

      else{
      $candidate_name_2=$row['candidate_name']; // second candidate name
      $candidate_2=$row['candidate_cvotes']; // second candidate votes
	  $flag=True;
	  echo "<br>".$candidate_name_2.": votes = ".$candidate_2."<br><img src='images/candidate-2.gif'style='width:".(100*round($candidate_2/($sum),2))."%;height:20px;'>";
	  echo "<br>".(100*round($candidate_2/($sum),2))." % of ".$sum." total votes<br><br>";
	}}

}
?>
  
</blockquote>
        
      </li> 

    </ul>
   
  </section>
</div>
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
   
    <div class="one_third first">
      <h6 class="title">Address</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
         
          <p>
          Name        : Miss. Suvarna Gaikwad <br>
          University  : DMCE <br>
          Batch       : 2k20 <br>
          Dept        : CSE <br>
          </p>
          </address>
        </li>
      </ul>
    </div>

    <div class="one_third">
      <h6 class="title">Phone</h6>
      <ul class="nospace linklist contact">
       
        <li><i class="fa fa-phone"></i> +8801773254014<br>
          +8801521479574</li>


      </ul>
    </div>

    <div class="one_third">
      <h6 class="title">Email</h6>
      <ul class="nospace linklist contact">
        
        <li><i class="fa fa-envelope-o"></i> suvarnawg10@gmail.com </li>

      </ul>
    </div>

  </footer>
</div>

<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
   
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="#">Miss. Suvarna Gaikwad</a></p>
   
   
  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<!-- IE9 Placeholder Support -->
<script src="layout/scripts/jquery.placeholder.min.js"></script>
<!-- / IE9 Placeholder Support -->
</body>
</html>

